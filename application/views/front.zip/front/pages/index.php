        <!-- Slider Area Start Here -->
        <div class="slider-area slider-layout1">
            <div class="bend niceties preview-1">
                <div id="ensign-nivoslider-4" class="slides">
                    <img src="<?php echo base_url();?>assets/img/slider/slide4-1.jpg" alt="slider" title="#slider-direction-1" />
                    <img src="<?php echo base_url();?>assets/img/slider/slide4-2.jpg" alt="slider" title="#slider-direction-2" />
                    <img src="<?php echo base_url();?>assets/img/slider/slide1-3.jpg" alt="slider" title="#slider-direction-3" />
                </div>
                <div id="slider-direction-1" class="t-cn slider-direction">
                    <div class="slider-content s-tb slide-1">
                        <div class="text-left title-container s-tb-c">
                            <div class="container">
                                <div class="slider-sub-text">The Best Cleaning Service Ever!</div>
                                <h1 class="slider-big-text">Certified Company</h1>
                                <div class="slider-paragraph">Our best-in-class WordPress solution, 
                                    with additional optimization to make running a WooCommerce online 
                                    store easy. Our prices are clear and straight forward so you can.</div>
                                <div class="slider-btn-area">
                                    <a href="#" class="item-btn-fill">Take Our Service
                                        <i class="fas fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="slider-direction-2" class="t-cn slider-direction">
                    <div class="slider-content s-tb slide-2">
                        <div class="text-left title-container s-tb-c">
                            <div class="container">
                                <div class="slider-sub-text">The Best Cleaning Service Ever!</div>
                                <h1 class="slider-big-text">Certified Company</h1>
                                <div class="slider-paragraph">Our best-in-class WordPress solution, 
                                    with additional optimization to make running a WooCommerce online 
                                    store easy. Our prices are clear and straight forward so you can.</div>
                                <div class="slider-btn-area">
                                    <a href="#" class="item-btn-fill">Take Our Service
                                        <i class="fas fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="slider-direction-3" class="t-cn slider-direction">
                    <div class="slider-content s-tb slide-3">
                        <div class="text-left title-container s-tb-c">
                            <div class="container">
                                <div class="slider-sub-text">The Best Cleaning Service Ever!</div>
                                <h1 class="slider-big-text">Certified Company</h1>
                                <div class="slider-paragraph">Our best-in-class WordPress solution, 
                                    with additional optimization to make running a WooCommerce online 
                                    store easy. Our prices are clear and straight forward so you can.</div>
                                <div class="slider-btn-area">
                                    <a href="#" class="item-btn-fill">Take Our Service
                                        <i class="fas fa-angle-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        </div>
        <!-- Slider Area End Here -->
        <!-- Why Choose Us Area Start Here -->
        <section class="why-choose-wrap-layout2 section-shape4">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="why-choose-box-layout3">
                            <h2 class="item-title">The Best Residential &amp; Commercial Cleaning Company in Town.</h2>
                            <p>Spa isa  newsimply dummy text of the printing and type settingare industrLorem 
                                Ipsum has been the industry's standard dummy text everty since the when an 
                                unknown centuries, but also the leap into electronic typesetting, remaining 
                                essentially.Spa isa  newsimpl year dummy text of the printing and type 
                                settingare industrLorem Ipsum has been the industry's standard dummy 
                                text everty since the when  electronic remaining essentially.</p>
                                <div class="item-sign">
                                    <img src="<?php echo base_url();?>assets/img/figure/signature.png" alt="sign">
                                </div>
                                <div class="item-designation">Ceo, Clenix Agency</div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="why-choose-box-layout4">
                            <div class="row gutters-20">
                                <div class="col-md-6">
                                    <div class="single-content">
                                        <div class="item-icon">
                                            <i class="fas fa-users"></i>
                                        </div>
                                        <div class="item-content">
                                            <h3 class="item-title">Trusted <span>Cleaners</span></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="single-content">
                                        <div class="item-icon">
                                            <i class="far fa-clock"></i>
                                        </div>
                                        <div class="item-content">
                                            <h3 class="item-title">On TIme &amp; <span>Reliable</span></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="single-content">
                                        <div class="item-icon">
                                            <i class="far fa-hand-peace"></i>
                                        </div>
                                        <div class="item-content">
                                            <h3 class="item-title">Best<span>Quality Work</span></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="single-content">
                                        <div class="item-icon">
                                            <i class="far fa-life-ring"></i>
                                        </div>
                                        <div class="item-content">
                                            <h3 class="item-title">24/7<span>Support Team</span></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Why Choose Us Area End Here -->
        <!-- Service Area Start Here -->
        <section class="section-padding-lg bg-common bg-Primary" data-bg-image="img/figure/bg-shape.png">
            <div class="container">
                <div class="heading-layout3">
                    <h2>Cleaning Services</h2>
                    <p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium dol
                        oremque laudantium, totam remeaque ipsa</p>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="service-box-layout1 dark-shadow-hover">
                            <div class="item-img">
                                <img src="<?php echo base_url();?>assets/img/service/service.jpg" alt="Thumb">
                            </div>
                            <div class="item-middle-content">
                                <div class="item-icon">
                                    <div class="home-icon">
                                        <i class="fas fa-home"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-service1.html">Residential</a></h3>
                                <div class="serivce-list">
                                    <ul>
                                        <li>Kitchen</li>
                                        <li>Bathrooms</li>
                                        <li>Bedrooms</li>
                                        <li>Windows</li>
                                        <li>Carpet</li>
                                        <li>Move in/out</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="service-box-layout1 dark-shadow-hover">
                            <div class="item-img">
                                <img src="<?php echo base_url();?>assets/img/service/service1.jpg" alt="Thumb">
                            </div>
                            <div class="item-middle-content">
                                <div class="item-icon">
                                    <div class="home-icon">
                                        <i class="far fa-building"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-service1.html">Commercial</a></h3>
                                <div class="serivce-list">
                                    <ul>
                                        <li>Kitchen</li>
                                        <li>Bathrooms</li>
                                        <li>Bedrooms</li>
                                        <li>Windows</li>
                                        <li>Carpet</li>
                                        <li>Move in/out</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 d-block d-md-none d-lg-block col-12">
                        <div class="service-box-layout1 dark-shadow-hover">
                            <div class="item-img">
                                <img src="<?php echo base_url();?>assets/img/service/service2.jpg" alt="Thumb">
                            </div>
                            <div class="item-middle-content">
                                <div class="item-icon">
                                    <div class="home-icon">
                                            <i class="fas fa-car"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-service1.html">Vehicle Wash</a></h3>
                                <div class="serivce-list">
                                    <ul>
                                        <li>Kitchen</li>
                                        <li>Bathrooms</li>
                                        <li>Bedrooms</li>
                                        <li>Windows</li>
                                        <li>Carpet</li>
                                        <li>Move in/out</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Service Area End Here -->
        <!-- Banner Area Start Here -->
        <section class="banner-wrap-layout2" data-bg-image="img/figure/banner-bg1.jpg">
            <div class="container">
                <div class="row d-flex align-items-center">
                    <div class="col-lg-6 col-12">
                        <div class="banner-box-layout4">
                            <h2 class="item-title text-Primary">Together <span>We'll Explore</span> New Things</h2>
                            <a href="#" class="btn-fill-md bg-accent btn-slide-hover text-primarytext">Book an Appointment<i class="fas fa-angle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="banner-box-layout5">
                        <div class="item-icon shape1">
                                <img src="<?php echo base_url();?>assets/img/figure/icon-shape4.png" alt="shape">
                            </div>
                            <div class="item-icon shape2">
                                <img src="<?php echo base_url();?>assets/img/figure/icon-shape3.png" alt="shape">
                            </div>
                            <div class="item-icon shape3">
                                <img src="<?php echo base_url();?>assets/img/figure/icon-shape2.png" alt="shape">
                            </div>
                            <div class="item-icon shape4">
                                <img src="<?php echo base_url();?>assets/img/figure/icon-shape1.png" alt="shape">
                            </div>
                            <div class="item-img">
                                <img src="<?php echo base_url();?>assets/img/figure/banner-figure.png" alt="figure">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Banner Area End Here -->
        <!-- Team Area Start Here -->
        <section class="section-padding-lg">
            <div class="container">
                <div class="heading-layout1">
                    <h2>Our Working Experts</h2>
                    <p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium dol
                        oremque laudantium, totam remeaque ipsa</p>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-box-layout4">
                            <div class="item-img">
                                <img src="<?php echo base_url();?>assets/img/team/team14.png" alt="team-thumb">
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-team.html">Richard Powel</a></h3>
                                <div class="item-subtitle">Office Cleaner</div>
                                <div class="item-social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-box-layout4">
                            <div class="item-img">
                                <img src="<?php echo base_url();?>assets/img/team/team1.png" alt="team-thumb">
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-team.html">Richard Powel</a></h3>
                                <div class="item-subtitle">Office Cleaner</div>
                                <div class="item-social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-box-layout4">
                            <div class="item-img">
                                <img src="<?php echo base_url();?>assets/img/team/team10.png" alt="team-thumb">
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-team.html">Richard Powel</a></h3>
                                <div class="item-subtitle">Office Cleaner</div>
                                <div class="item-social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="team-box-layout4">
                            <div class="item-img">
                                <img src="<?php echo base_url();?>assets/img/team/team3.png" alt="team-thumb">
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-team.html">Richard Powel</a></h3>
                                <div class="item-subtitle">Office Cleaner</div>
                                <div class="item-social">
                                    <ul>
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Team Area End Here -->
        <!-- Progress Area Start Here -->
        <section class="progress-wrap-layout3 section-padding-12">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-8 col-12">
                        <div class="progress-box-layout1">
                            <h2 class="item-title">All of our Specialists are Fully Trained</h2>
                            <div class="item-content">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="counter-item">
                                            <div class="counter count-number" data-num="159">159</div>
                                            <div class="count-title">Project Done</div>
                                            <div class="bg-icon"><i class="far fa-thumbs-up"></i></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="counter-item">
                                            <div class="counter count-number" data-num="1900">1900</div>
                                            <div class="count-title">Happy Clients</div>
                                            <div class="bg-icon"><i class="far fa-smile"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Progress Area End Here -->
        <!-- About Us Area Start Here -->
        <section class="section-padding-12-9 section-shape4">
            <div class="container">
                <div class="row">
                    <div class="col-xl-7 col-12">
                        <div class="faq-box-layout1 mb-5 mb-xl-0">
                            <h2 class="faq-title">Frequently Asked Any Question</h2>
                            <p class="mb-5">Ahen an unknown printer took a galley of type and scrambled it to make a 
                                type specimen book. It has survived not only five centuries.</p>
                            <div id="accordion" class="accordion">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="heading-title" data-toggle="collapse" data-target="#collapseOne" 
                                            aria-expanded="true" aria-controls="collapseOne">Do i have to sign a contract?</h5>
                                    </div>
                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                        <div class="card-body">
                                            Ahen an unknown printer took a galley of type and scrambled it to make a 
                                            type specimen book areIt hasear survived not only five centuries, but 
                                            also the leap into electronic typesetting, remaining essentiall yellow 
                                            aw unchangedh.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                        <h5 class="heading-title collapsed" data-toggle="collapse" data-target="#collapseTwo" 
                                        aria-expanded="false" aria-controls="collapseTwo">Will i always have the same house cleaner?</h5>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                        <div class="card-body">
                                            Ahen an unknown printer took a galley of type and scrambled it to make a 
                                            type specimen book areIt hasear survived not only five centuries, but 
                                            also the leap into electronic typesetting, remaining essentiall yellow 
                                            aw unchangedh.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingThree">
                                        <h5 class="heading-title collapsed" data-toggle="collapse" data-target="#collapseThree" 
                                            aria-expanded="false" aria-controls="collapseThree">Do you Guatantee your work?</h5>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                        <div class="card-body">
                                            Ahen an unknown printer took a galley of type and scrambled it to make a 
                                            type specimen book areIt hasear survived not only five centuries, but 
                                            also the leap into electronic typesetting, remaining essentiall yellow 
                                            aw unchangedh.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFour">
                                        <h5 class="heading-title collapsed" data-toggle="collapse" data-target="#collapseFour" 
                                            aria-expanded="false" aria-controls="collapseFour">How i can payment?</h5>
                                    </div>
                                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                        <div class="card-body">
                                            Ahen an unknown printer took a galley of type and scrambled it to make a 
                                            type specimen book areIt hasear survived not only five centuries, but 
                                            also the leap into electronic typesetting, remaining essentiall yellow 
                                            aw unchangedh.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFive">
                                        <h5 class="heading-title collapsed" data-toggle="collapse" data-target="#collapseFive" 
                                            aria-expanded="false" aria-controls="collapseFive">Can i cleaning professionals for a month?</h5>
                                    </div>
                                    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
                                        <div class="card-body">
                                            Ahen an unknown printer took a galley of type and scrambled it to make a 
                                            type specimen book areIt hasear survived not only five centuries, but 
                                            also the leap into electronic typesetting, remaining essentiall yellow 
                                            aw unchangedh.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-5 col-12">
                        <div class="about-box-layout2">
                            <h3 class="item-title">REQUEST AN ESTIMATE</h3>
                            <form class="contact-form-box" id="contact-form">
                                <div class="row gutters-10">
                                    <div class="col-12 form-group">
                                        <select class="select2">
                                            <option value="0">Residential</option>
                                            <option value="1">Residential</option>
                                            <option value="2">Commercial</option>
                                            <option value="3">Plot</option>
                                            <option value="4">Apartment</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-12 form-group">
                                        <select class="select2">
                                            <option value="0">Property Type</option>
                                            <option value="1">Residential</option>
                                            <option value="2">Commercial</option>
                                            <option value="3">Plot</option>
                                            <option value="4">Apartment</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-12 form-group">
                                        <select class="select2">
                                            <option value="0">-- Approx SF --</option>
                                            <option value="1">400</option>
                                            <option value="2">200</option>
                                            <option value="3">600</option>
                                            <option value="4">300</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-12 form-group">
                                        <select class="select2">
                                            <option value="0">-- Bedrooms --</option>
                                            <option value="1">Residential</option>
                                            <option value="2">Commercial</option>
                                            <option value="3">Plot</option>
                                            <option value="4">Apartment</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-12 form-group">
                                        <select class="select2">
                                            <option value="0">-- Bathrooms --</option>
                                            <option value="1">Residential</option>
                                            <option value="2">Commercial</option>
                                            <option value="3">Plot</option>
                                            <option value="4">Apartment</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-12 form-group">
                                        <select class="select2">
                                            <option value="0">-- Frequency --</option>
                                            <option value="1">Residential</option>
                                            <option value="2">Commercial</option>
                                            <option value="3">Plot</option>
                                            <option value="4">Apartment</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-12 form-group">
                                        <input type="text" placeholder="ZIP Code" class="form-control" name="name" data-error="zip code field is required" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="col-md-6 col-12 form-group datetime-picker">
                                        <i class="far fa-calendar-alt"></i>
                                        <input type="text" class="form-control rt-date" placeholder="dd/mm/yy" name="date" id="form-date" data-error="Subject field is required" required/>
                                    </div>
                                    <div class="col-md-6 col-12 form-group datetime-picker">
                                        <i class="far fa-clock"></i>
                                        <input type="text" class="form-control rt-time" placeholder="Time" name="time" id="form-time" data-error="Subject field is required" required/>
                                    </div>
                                    <div class="col-md-6 col-12 form-group">
                                        <input type="text" placeholder="Name" class="form-control" name="name" data-error="Name field is required" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="col-md-6 col-12 form-group">
                                        <input type="text" placeholder="Phone" class="form-control" name="phone" data-error="Phone field is required" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="col-12 form-group">
                                        <input type="email" placeholder="E-mail Address" class="form-control" name="email" data-error="email field is required" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="col-12 form-group mg-b-20">
                                        <textarea placeholder="Address" class="textarea form-control" name="message" id="form-message" rows="2" cols="20" 
                                        data-error="Message field is required" required></textarea>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="col-12 form-group">
                                        <button type="submit" class="fw-btn-fill bg-accent text-primarytext">Book Now<i class="fas fa-angle-right"></i></button>
                                    </div>
                                </div>
                                <div class="form-response"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Us Area End Here -->
        <!-- Testimonial Area Start Here -->
        <section class="section-padding-12 bg-Primary bg-common" data-bg-image="img/figure/bg-shape.png">
            <div class="container">
                <div class="heading-layout2 mg-b-30">
                    <h2 class="text-white">Client’s Say About Us</h2>
                </div>
                <div class="rc-carousel nav-control-layout3" data-loop="true" data-items="10" data-margin="30"
                    data-autoplay="false" data-autoplay-timeout="3000" data-smart-speed="1000" data-dots="false"
                    data-nav="true" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="true"
                    data-r-x-small-dots="false" data-r-x-medium="1" data-r-x-medium-nav="true" data-r-x-medium-dots="false"
                    data-r-small="1" data-r-small-nav="true" data-r-small-dots="false" data-r-medium="1"
                    data-r-medium-nav="true" data-r-medium-dots="false" data-r-large="1" data-r-large-nav="true"
                    data-r-large-dots="false" data-r-extra-large="1" data-r-extra-large-nav="true"
                    data-r-extra-large-dots="false">
                    <div class="testimonial-box-layout3">
                        <div class="item-author">
                            <img src="<?php echo base_url();?>assets/img/figure/author.jpg" alt="author">
                        </div>
                        <p>Wimply dummy text of the printing and typesetting industryrem Ipsum has been the 
                            industry's stawhen an unknown printer took a galley of type and scramb
                            led it to make a type specimen book. </p>
                        <h3 class="item-title">Steven Joes</h3>
                        <div class="item-subtitle">CEO, RT</div>
                        <ul class="item-rating">
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                        </ul>
                        <div class="item-quote"><i class="fas fa-quote-right"></i></div>
                    </div>
                    <div class="testimonial-box-layout3">
                        <div class="item-author">
                            <img src="<?php echo base_url();?>assets/img/figure/author.jpg" alt="author">
                        </div>
                        <p>Wimply dummy text of the printing and typesetting industryrem Ipsum has been the 
                            industry's stawhen an unknown printer took a galley of type and scramb
                            led it to make a type specimen book. </p>
                        <h3 class="item-title">Steven Joes</h3>
                        <div class="item-subtitle">CEO, RT</div>
                        <ul class="item-rating">
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                            <li><i class="fas fa-star"></i></li>
                        </ul>
                        <div class="item-quote"><i class="fas fa-quote-right"></i></div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Testimonial Area End Here -->
        <!-- Blog Area Start Here -->
        <section class="section-padding-lg bg-assh">
            <div class="container">
                <div class="heading-layout1">
                    <h2> Our Latest Blogs</h2>
                    <p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium fa-angle-double-up
                    oremque laudantium, totam remeaque ipsa</p>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="blog-box-layout2">
                            <div class="item-img">
                                <a href="single-blog1.html"><img src="<?php echo base_url();?>assets/img/blog/blog15.jpg" alt="blog-thumb"></a>
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-blog1.html">5 Star Google Review for Tallmadge, OH House ...</a></h3>
                                <div class="entry-info">
                                    <ul>
                                        <li><i class="fas fa-calendar-alt"></i>24 July, 2019</li>
                                        <li><i class="fas fa-user"></i>By Mark Wily</li>
                                    </ul>
                                </div>
                                <p>Aimply dummy text of the printing anden type setting industrym Ipsum has 
                                    been the industry's standard.</p>
                                <div class="entry-meta">
                                    <ul>
                                        <li><i class="fas fa-heart"></i><span>06</span> Likes</li>
                                        <li><i class="fas fa-comment"></i><span>02</span> <a href="#">Comments</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="blog-box-layout2">
                            <div class="item-img">
                                <a href="single-blog1.html"><img src="<?php echo base_url();?>assets/img/blog/blog17.jpg" alt="blog-thumb"></a>
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-blog1.html">5 Star Google Review for Tallmadge, OH House ...</a></h3>
                                <div class="entry-info">
                                    <ul>
                                        <li><i class="fas fa-calendar-alt"></i>24 July, 2019</li>
                                        <li><i class="fas fa-user"></i>By Mark Wily</li>
                                    </ul>
                                </div>
                                <p>Aimply dummy text of the printing anden type setting industrym Ipsum has 
                                    been the industry's standard.</p>
                                <div class="entry-meta">
                                    <ul>
                                        <li><i class="fas fa-heart"></i><span>06</span> Likes</li>
                                        <li><i class="fas fa-comment"></i><span>02</span> <a href="#">Comments</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 d-block d-md-none d-lg-block col-12">
                        <div class="blog-box-layout2">
                            <div class="item-img">
                                <a href="single-blog1.html"><img src="<?php echo base_url();?>assets/img/blog/blog16.jpg" alt="blog-thumb"></a>
                            </div>
                            <div class="item-content">
                                <h3 class="item-title"><a href="single-blog1.html">5 Star Google Review for Tallmadge, OH House ...</a></h3>
                                <div class="entry-info">
                                    <ul>
                                        <li><i class="fas fa-calendar-alt"></i>24 July, 2019</li>
                                        <li><i class="fas fa-user"></i>By Mark Wily</li>
                                    </ul>
                                </div>
                                <p>Aimply dummy text of the printing anden type setting industrym Ipsum has 
                                    been the industry's standard.</p>
                                <div class="entry-meta">
                                    <ul>
                                        <li><i class="fas fa-heart"></i><span>06</span> Likes</li>
                                        <li><i class="fas fa-comment"></i><span>02</span> <a href="#">Comments</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Blog Area End Here -->
        <!-- Action Area Start Here -->
        <section class="action-wrap-layout2">
            <div class="container">
                <div class="row d-flex align-items-center">
                    <div class="col-lg-7 col-md-6">
                        <div class="action-box-layout2">
                            <h2 class="item-title">SignUp for News &amp; Special Offers!</h2>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-6">
                        <div class="action-box-layout2">
                            <div class="newsletter-form">
                                <div class="input-group stylish-input-group">
                                    <input type="text" class="form-control" placeholder="Enter your E-mail">
                                    <span class="input-group-addon">
                                        <button type="submit">Submit<i class="fas fa-angle-right"></i></button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Action Area End Here -->
       