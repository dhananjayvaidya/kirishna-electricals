<?php 
    require "sections/header.php";
    require "pages/".$page.".php";
    require "sections/footer.php";
?>