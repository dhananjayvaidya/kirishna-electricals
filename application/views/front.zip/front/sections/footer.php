 <!-- Footer Area Start Here -->
        <footer class="footer-wrap-layout1 section-shape1">
            <div class="container">
                <div class="footer-top-box">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="footer-box-layout1">
                                <div class="footer-title">
                                    <h4>FEATURES</h4>
                                </div>
                                <div class="footer-menu-box">
                                    <ul class="footer-menu-list">
                                        <li>
                                            <a href="#">Residential Services</a>
                                        </li>
                                        <li>
                                            <a href="#">Commercial Services</a>
                                        </li>
                                        <li>
                                            <a href="#">Vechile Wash</a>
                                        </li>
                                        <li>
                                            <a href="#">Londry Facilities</a>
                                        </li>
                                        <li>
                                            <a href="#">Carpet Removal</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="footer-box-layout1">
                                <div class="footer-title">
                                    <h4>COMPANY</h4>
                                </div>
                                <div class="footer-menu-box">
                                    <ul class="footer-menu-list">
                                        <li>
                                            <a href="about1.html">About Us</a>
                                        </li>
                                        <li>
                                            <a href="#">Testimonials</a>
                                        </li>
                                        <li>
                                            <a href="#">Terms</a>
                                        </li>
                                        <li>
                                            <a href="#">Media Kit</a>
                                        </li>
                                        <li>
                                            <a href="#">Sitemap</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="footer-box-layout1">
                                <div class="footer-title">
                                    <h4>QUICK LINKS</h4>
                                </div>
                                <div class="footer-menu-box">
                                    <ul class="footer-menu-list">
                                        <li>
                                            <a href="#">Features</a>
                                        </li>
                                        <li>
                                            <a href="#">Pricing</a>
                                        </li>
                                        <li>
                                            <a href="#">Partners</a>
                                        </li>
                                        <li>
                                            <a href="#">Cloud Affiliate Program</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="footer-box-layout1">
                                <div class="footer-title">
                                    <h4>SIGN UP!</h4>
                                </div>
                                <div class="footer-newsletter">
                                    <p>Quuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
                                    <div class="input-group stylish-input-group">
                                        <input type="text" class="form-control" placeholder="E-mail Address">
                                        <span class="input-group-addon">
                                            <button type="submit">Submit</button>
                                        </span>
                                    </div>
                                </div>
                                <div class="footer-social">
                                    <ul class="social-icon">
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                        <li><a href="#"><i class="fab fa-pinterest"></i></a></li>
                                        <li><a href="#"><i class="fab fa-vimeo-v"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom-box">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="copyright">Copyright 2019 clenix. All Rights Reserved.</div>
                        </div>
                        <div class="col-md-6">
                            <div class="footer-bottom-menu">
                                <ul>
                                    <li><a href="#">Sitemap</a></li>
                                    <li><a href="#">Terms of Service</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Area End Here -->
    </div>
    <!-- jquery-->
    <script src="<?php echo base_url();?>assets/js/jquery-3.3.1.min.js"></script>
    <!-- Plugins js -->
    <script src="<?php echo base_url();?>assets/js/plugins.js"></script>
    <!-- Popper js -->
    <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <!-- MeanMenu js -->
    <script src="<?php echo base_url();?>assets/js/jquery.meanmenu.min.js"></script> 
    <!-- Nivo Slider js -->
    <script src="<?php echo base_url();?>assets/vendor/slider/js/jquery.nivo.slider.js"></script> 
    <script src="<?php echo base_url();?>assets/vendor/slider/home.js"></script> 
    <!-- Owl Carousel js --> 
    <script src="<?php echo base_url();?>assets/vendor/OwlCarousel/owl.carousel.min.js"></script> 
    <!-- CounterUp js -->
    <script src="<?php echo base_url();?>assets/js/jquery.counterup.min.js"></script> 
    <!-- WayPoints js -->
    <script src="<?php echo base_url();?>assets/js/waypoints.min.js"></script> 
    <!-- Validator js -->
    <script src="<?php echo base_url();?>assets/js/validator.min.js"></script>
    <!-- Select 2 js -->
    <script src="<?php echo base_url();?>assets/js/select2.min.js"></script>
    <!-- Datetime Picker js -->
    <script src="<?php echo base_url();?>assets/js/jquery.datetimepicker.full.min.js"></script>
    <!-- Main js -->
    <script src="<?php echo base_url();?>assets/js/main.js"></script>

</body>

</html>