<!doctype html>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $page_title;?></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
    <!-- Normalize CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/normalize.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/main.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    <!-- MeanMenu CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/meanmenu.min.css">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/fontawesome-all.min.css">
    <!-- Animate CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/animate.min.css">
    <!-- FlatIcon CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/font/flaticon.css">
    <!-- Nivo Slider CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/slider/css/nivo-slider.css">
    <!-- Owl Carousel CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/OwlCarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendor/OwlCarousel/owl.theme.default.min.css">
    <!-- Select 2 CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/select2.min.css">
    <!-- Datetime Picker CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery.datetimepicker.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/style.css">
    <!-- Modernize js -->
    <script src="<?php echo base_url();?>assets/js/modernizr-3.7.1.min.js"></script>
</head>

<body class="sticky-header">
    <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
      <![endif]-->
    <!-- ScrollUp Start Here -->
    <a href="#wrapper" data-type="section-switch" class="scrollup">
        <i class="fas fa-angle-double-up"></i>
    </a>
    <!-- ScrollUp End Here -->
    <div id="wrapper" class="wrapper overflow-hidden">
        <!-- Add your site or application content here -->
        <!-- Header Area Start Here -->
        <header class="header">
            <div id="header-topbar" class="bg-Primary pd-y-10">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <div class="col-lg-6">
                            <div class="header-topbar-layout2">
                                <div class="header-top-left">
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 d-flex justify-content-end">
                            <div class="header-topbar-layout2">
                                <ul class="header-top-right">
                                    <li class="social-icon icon-light">
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#"><i class="fab fa-twitter"></i></a>
                                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                        <a href="#"><i class="fab fa-google-plus-g"></i></a>
                                        <a href="#"><i class="fab fa-pinterest"></i></a>
                                        <a href="#"><i class="fab fa-snapchat-ghost"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="rt-sticky-placeholder"></div>
            <div id="header-menu" class="header-menu menu-layout1">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo-area">
                                <a href="<?php echo base_url();?>" class="temp-logo">
                                    <img src="<?php echo base_url();?>assets/img/logo.png" alt="logo" class="img-fluid">
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-7 d-flex justify-content-end position-static">
                            <nav id="dropdown" class="template-main-menu">
                                <ul>
                                   <li>
                                        <a href="<?php echo base_url();?>">Home</a>
                                        
                                    </li>
                                    <li>
                                        <a href="<?php echo base_url();?>about-us">About</a>
                                        
                                    </li>
                                    <li>
                                        <a href="#">Products</a>
                                        <ul class="dropdown-menu-col-1">
                                            <li>
                                                <a href="<?php echo base_url();?>products/basic-bags">Basic Bags</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo base_url();?>products/mineral-bags">Mineral Bags</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo base_url();?>products/builder-bags">Builder bags</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo base_url();?>products/agro-bags">Agro Bags</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo base_url();?>products/bags-for-recyclable-products">Bags for Recyclable Products</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo base_url();?>products/fibc-liners">FIBC Liners</a>
                                            </li>
                                        </ul>
                                    </li>
                                    
                                    
                                    <li>
                                        <a href="<?php echo base_url();?>contact-us">Contact</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-lg-3 d-flex justify-content-end">
                            <div class="header-action-layout1">
                                <ul>
                                    <li class="header-action-number-2">
                                        <div class="item-icon">
                                            <i class="flaticon-phone-call"></i>
                                        </div>
                                        <div class="item-content">
                                            <div class="item-number">+ 985 8844 000</div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header Area End Here -->
