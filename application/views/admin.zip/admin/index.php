<?php require "section/header.php";?>
<?php 
    $this->load->view('admin/pages/'.$page.'.php');
?>
<?php require "section/footer.php";?>